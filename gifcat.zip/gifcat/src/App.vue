<template>
  <!--<img alt="Vue logo" src="./assets/logo.png">
  <HelloWorld msg="Welcome to Your Vue.js App"/>-->
  <div>
    <h1>Random Gif Cat</h1>
    <form>
      <p><label>Título: </label><input type="text" default="Miau" placeholder="Miau"></p>
      <p>
        <label>Filtro: </label>
        <select>
          <option value="blur">Blur</option>
          <option value="mono">Mono</option>
          <option value="sepia">Sepia</option>
          <option value="negative">Negative</option>
          <option value="paint">Paint</option>
          <option value="pixel">Pixel</option>
        </select>
      </p>
      <p>
        <label>Color: </label>
        <select name="color" id="color">
          <option value="red">Rojo</option>
          <option value="blue">Azul</option>
          <option value="green">Verde</option>
          <option value="white">Blanco</option>
          <option value="yellow">Amarillo</option>
        </select>
        <span class="colorSeleccionado"></span>
      </p>
      <p><label>Tamaño: </label><input type="text" placeholder="300"></p>
      <input type="submit" value="obtener mi gato" @click='apiCat'>
    </form>

    <div id='resultado'></div>
  </div>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  //components: {
    //HelloWorld
  //},
  data() {
    return {
      title: 'Miau',
      colorfilterSelected: 'sepa',
      colorSelected: 'rojo',
      size: '100px',
      foto: '',
      imagen:''
    }
  },// fin data

  methods: {
    async apiCat() {
      const url = 'https://cataas.com/cat/gif/says';
      try {
        this.foto = `${url}/${this.title}?filter=${this.filterSelected}&color=${this.colorSelected}&size=${this.size}&type=or`;
        //console.log(url);
        let resultado = document.getElementById('resultado');
        resultado.innerHTML = `${this.foto}`;
        console.log(`${this.foto}`);
      } catch(error) {
        console.error('Sitio no encontrado', error);
      }
    }
  },// fin methods

  created() {
    this.apiCat();
  }
}
</script>

<style>
#app {
  background-color: rgb(0, 238, 255);
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
form {
  background-color: pink;
  padding: 2%;
}
label {
  background-color: aquamarine;
  margin: 1%;
  width: 25rem;
}
#resultado {
  width: 50px;
  height: 50px;
  display: auto;
}
.colorSeleccionado {
  border-radius: 50%;
  background-color: red;
  width: 50px;
  height: 50px;
}
</style>
